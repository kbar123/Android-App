package com.example.cyber.karniapp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class RandList {

    List<String> randomSeries;

    public RandList()
    {
        List<String> DrawObjectsList = Arrays.asList("Books", "Trophy", "Statue", "Dog", "Cat", "House", "Bicycle", "Map", "Diamond", "Toothpaste",
                    "Sunglasses", "Ring", "Trees", "Tent", "Beach", "Pizza", "Newspaper", "Skateboard", "Sandwich", "Skull", "Cake", "Shoes", "Drums", "Computer", "Giraffe",
                    "Phone", "Apple", "Witch", "Snake", "Bee", "Pool", "MotorCycle", "Flag", "Coins", "Frog", "Sword", "Horse", "Bird", "Pencil", "Ship", "Turkey", "Basketball",
                    "Airplane", "Crown", "Dinosaur", "Castle", "Gun", "Baby", "Fork", "Candy", "Moon", "Sushi", "Coffee", "Fish", "Flower", "TV", "Toothbrush", "Turtle", "Duck",
                    "Bridge", "Ferris Wheel", "Bed", "Fire", "Crab", "Palm Tree", "Chair", "Binoculars", "Clock", "Donut", "Ceiling Fan", "Rose", "Robot", "Sky", "Dartboard",
                    "Window", "Chess", "Bones", "Cave", "Telescope", "Cowboy", "Surfer", "Cave", "Train", "Cookies", "Shark", "Teeth", "Mouth", "Ladder", "Chef", "Doctor",
                    "Tornado", "Farmer", "Pretzel", "Alien", "Rollercoaster", "Desk", "Bear", "Sweatshirt", "Pants", "Shirt", "	Spider", "Car", "Firefighter", "Lightning",
                    "Police", "Bats", "Scuba Diver", "Rat", "Rain", "Snow", "Clown", "Worms", "Mushrooms", "Pirate", "Jumprope", "Feet", "Taco", "Camel", "Mermaid", "Feather");

            Collections.shuffle(DrawObjectsList);
            int randomSeriesLength = 3;
            List<String> randomSeries = DrawObjectsList.subList(0, randomSeriesLength);
    }

    public List<String> GetVal()
    {
        return randomSeries;
    }

    public static void main(String[]args)
    {
        RandList newlist = new RandList();
        System.out.print(newlist.toString());
    }
}



